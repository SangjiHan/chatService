package com.app.chatservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Date;
// import org.springframework.data.jpa.repository.Query;

import com.app.chatservice.entities.AppUserEntity;
import com.app.chatservice.entities.ServerEntity;

public interface ServerRepository extends JpaRepository<ServerEntity, String> {
    
    // ServerId로 서버 찾기
    ServerEntity findByServerId(String serverId);
    // ServerName으로 서버 찾기
    ServerEntity findByServerName(String serverName);
    // ServerOwner로 서버 모두 찾기
    List<ServerEntity> findByServerOwner(AppUserEntity serverOwner);
    // ServerRegDate로 서버 모두 찾기
    List<ServerEntity> findByServerRegDate(Date serverRegDate);
    // ServerPfp로 서버 모두 찾기
    List<ServerEntity> findByServerPfp(String serverPfp);
    // ServerDesc로 서버 모두 찾기
    List<ServerEntity> findByServerDesc(String serverDesc);
}
