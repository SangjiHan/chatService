package com.app.chatservice.repositories;

import java.util.List;
import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.chatservice.entities.AppUserEntity;
import com.app.chatservice.entities.ChannelEntity;
import com.app.chatservice.entities.GroupChatEntity;
import com.app.chatservice.entities.MessageEntity;

public interface MessageRepository extends JpaRepository<MessageEntity, String> {

    MessageEntity findByMessageId(String messageId);
    List<MessageEntity> findByMessageChannel(ChannelEntity messageChannel);
    List<MessageEntity> findByMessageGroupChat(GroupChatEntity messageGroupChat);
    List<MessageEntity> findByMessageUser(AppUserEntity messageUser);
    List<MessageEntity> findByMessageRegDate(Date messageRegDate);
    List<MessageEntity> findByMessageContent(String messageContent);
    List<MessageEntity> findByMessageEdited(int messageEdited);
    List<MessageEntity> findByMessageReplyTo(MessageEntity messageReplyTo);
    List<MessageEntity> findByMessagePing(int messagePing);
}
