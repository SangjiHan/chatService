package com.app.chatservice.repositories;

import java.util.Optional;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.chatservice.entities.AppUserEntity;
import com.app.chatservice.entities.GroupChatEntity;
import com.app.chatservice.entities.GroupChatUserEntity;
import com.app.chatservice.entities.GroupChatUserId;

public interface GroupChatUserRepository extends JpaRepository<GroupChatUserEntity, GroupChatUserId> {

    Optional<GroupChatUserEntity> findById(GroupChatUserId groupChatUserId);
    List<GroupChatUserEntity> findByGroupChatUserId_GroupChatUser(AppUserEntity groupChatUser);
    List<GroupChatUserEntity> findByGroupChatUserId_GroupChatUserGroup(GroupChatEntity groupChatUserGroup);
}
