package com.app.chatservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

import com.app.chatservice.entities.AppUserEntity;
import com.app.chatservice.entities.GroupChatEntity;

public interface GroupChatRepository extends JpaRepository<GroupChatEntity, String>{

    GroupChatEntity findByGroupChatId(String groupChatId);
    List<GroupChatEntity> findByGroupChatCreator(AppUserEntity groupChatCreator);
    List<GroupChatEntity> findByGroupChatName(String groupChatName);
}
