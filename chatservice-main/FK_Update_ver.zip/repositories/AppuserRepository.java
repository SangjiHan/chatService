package com.app.chatservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Date;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.chatservice.entities.AppUserEntity;

public interface AppuserRepository extends JpaRepository<AppUserEntity, String> {

    
    // boolean existsByAppuserUkName(String ukNameVal);
    @Query(value = "select appuser_uk_name from appuser where appuser_uk_name= ?1", 
        nativeQuery = true)
    String existsByAppuserUkName(String ukNameVal);

    // boolean existsByAppuserEmail(String emailVal);
    @Query(value = "select appuser_id from appuser where appuser_email= ?1",
        nativeQuery = true)
    String existsByAppuserEmail(String emailVal);

    // UserId로 회원 찾기 (Primary Key)
    AppUserEntity findByAppuserId(String appuserId);
    AppUserEntity findByAppuserId(AppUserEntity appUserEntity);
    // UkName으로 회원 찾기 (Unique Key)
    AppUserEntity findByAppuserUkName(String appuserUkName);
    // Email로 회원 찾기 (Unique Key)
    AppUserEntity findByAppuserEmail(String appuserEmail);
    // DisplayName으로 회원 모두 찾기
    List<AppUserEntity> findByAppuserDisplayName(String appuserDisplayName);
    // Password로 회원 모두 찾기
    List<AppUserEntity> findByAppuserPassword(String appuserPassword);
    // RegDate로 회원 모두 찾기
    List<AppUserEntity> findByAppuserRegDate(Date appuserRegDate);
    // GenPfp로 회원 모두 찾기
    List<AppUserEntity> findByAppuserGenPfp(String appuserGenPfp);
    // About으로 회원 모두 찾기
    List<AppUserEntity> findByAppuserAbout(String appuserAbout);

    // Email과 Password로 회원 찾기
    AppUserEntity findByAppuserEmailAndAppuserPassword(String appuserEmail, String appuserPassword);

    // UkName, DisplayName, Email 부분일치 찾기
    @Query("SELECT u FROM AppUserEntity u WHERE u.appuserUkName LIKE %:keyword% OR u.appuserDisplayName LIKE %:keyword% OR u.appuserEmail LIKE %:keyword%")
    List<AppUserEntity> findByUserKeyword(@Param("keyword") String keyword);
} 