package com.app.chatservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Date;
import java.util.List;

import com.app.chatservice.entities.ChannelEntity;
import com.app.chatservice.entities.ServerEntity;

public interface ChannelRepository extends JpaRepository<ChannelEntity, String> {

    // ChannelId로 채널 찾기
    ChannelEntity findByChannelId(String channelId);
    // ChannelName으로 채널 모두 찾기
    List<ChannelEntity> findByChannelName(String channelName);
    // ChannelServer로 채널 모두 찾기
    List<ChannelEntity> findByChannelServer(ServerEntity channelServer);
    // ChannelRegDate로 채널 모두 찾기
    List<ChannelEntity> findByChannelRegDate(Date channelRegDate);
}
