package com.app.chatservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.Date;

import com.app.chatservice.entities.AppUserEntity;
import com.app.chatservice.entities.ServerMemberEntity;
import com.app.chatservice.entities.ServerMemberId;

public interface ServerMemberRepository extends JpaRepository<ServerMemberEntity, ServerMemberId>{

    // memberUser와 memberServer로 멤버 찾기
    Optional<ServerMemberEntity> findById(ServerMemberId memberId);
    // memberRegDate로 멤버 모두 찾기
    List<ServerMemberEntity> findByServerMemberRegDate(Date serverMemberRegDate);
    // memberUserName으로 멤버 모두 찾기
    List<ServerMemberEntity> findByServerMemberUserName(String serverMemberUserName);
    // memberPfp로 멤버 모두 찾기
    List<ServerMemberEntity> findByServerMemberPfp(String serverMemberPfp);

    List<ServerMemberEntity> findByMemberId_ServerMemberUser(AppUserEntity serverMemberUser);
}
