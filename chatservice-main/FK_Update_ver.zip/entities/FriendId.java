package com.app.chatservice.entities;

import java.io.Serializable;
import java.util.Objects;

// import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Embeddable
public class FriendId implements Serializable {

    @ManyToOne
    @JoinColumn(name = "APPUSER_ID", insertable = false, updatable = false)
    private AppUserEntity friend1;

    @ManyToOne
    @JoinColumn(name = "APPUSER_ID", insertable = false, updatable = false)
    private AppUserEntity friend2;

    // 생성자
    public FriendId() {};
    public FriendId(AppUserEntity friend1, AppUserEntity friend2) {
        this.friend1 = friend1;
        this.friend2 = friend2;
    }

    public AppUserEntity getFriend1() {
        return friend1;
    }
    public void setFriend1(AppUserEntity friend1) {
        this.friend1 = friend1;
    }
    public AppUserEntity getFriend2() {
        return friend2;
    }
    public void setFriend2(AppUserEntity friend2) {
        this.friend2 = friend2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FriendId friendId = (FriendId) o;
        return Objects.equals(friend1, friendId.friend1) && 
                Objects.equals(friend2, friendId.friend2);
    }

    @Override
    public int hashCode() {
        return Objects.hash(friend1, friend2);
    }
}
