package com.app.chatservice.entities;

import java.io.Serializable;
import java.util.Objects;
// import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Embeddable
public class ReactionLogId implements Serializable {

	@ManyToOne
    @JoinColumn(name = "REACTION_ID")
    private ReactionEntity reactionLogReaction;

	@ManyToOne
    @JoinColumn(name = "MESSAGE_ID")
    private MessageEntity reactionLogMessage;

	@ManyToOne
    @JoinColumn(name = "APPUSER_ID")
    private AppUserEntity reactionLogReactor;

    public ReactionLogId() {}
    public ReactionLogId(ReactionEntity reactionLogReaction, MessageEntity reactionLogMessage, AppUserEntity reactionLogReactor) {
        this.reactionLogReaction = reactionLogReaction;
        this.reactionLogMessage = reactionLogMessage;
        this.reactionLogReactor = reactionLogReactor;
    }

    public ReactionEntity getReactionLogReaction() {
        return reactionLogReaction;
    }

    public void setReactionLogReaction(ReactionEntity reactionLogReaction) {
        this.reactionLogReaction = reactionLogReaction;
    }

    public MessageEntity getReactionLogMessage() {
        return reactionLogMessage;
    }

    public void setReactionLogMessage(MessageEntity reactionLogMessage) {
        this.reactionLogMessage = reactionLogMessage;
    }

    public AppUserEntity getReactionLogReactor() {
        return reactionLogReactor;
    }
    
    public void setReactionLogReactor(AppUserEntity reactionLogReactor) {
        this.reactionLogReactor = reactionLogReactor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReactionLogId reactionLogId = (ReactionLogId) o;
        return Objects.equals(reactionLogReaction, reactionLogId.reactionLogReaction) && 
                Objects.equals(reactionLogMessage, reactionLogId.reactionLogMessage) && 
                Objects.equals(reactionLogReactor, reactionLogId.reactionLogReactor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reactionLogReaction, reactionLogMessage, reactionLogReactor);
    }
}
