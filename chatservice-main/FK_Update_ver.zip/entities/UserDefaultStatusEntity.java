package com.app.chatservice.entities;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
// import jakarta.persistence.FetchType;
// import jakarta.persistence.GeneratedValue;
// import jakarta.persistence.GenerationType;
// import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
// import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "USER_DEFAULT_STATUS")
public class UserDefaultStatusEntity {
    
	@EmbeddedId
	private UserDefaultStatusId userDefaultStatusId;
	
	@OneToOne
	@MapsId("appUser")
	@JoinColumn(name = "APPUSER_ID")
    private AppUserEntity userDefaultStatusUser;

	@Column(name = "USER_DEFAULT_STATUS_STATUS")
    private String userDefaultStatusStatus;

	public UserDefaultStatusId getUserDefaultStatusId() {
		return this.userDefaultStatusId;
	}

	public void setUserDefaultStatusId(UserDefaultStatusId userDefaultStatusId) {
		this.userDefaultStatusId = userDefaultStatusId;
	}

	public AppUserEntity getUserDefaultStatusUser() {
		return this.userDefaultStatusUser;
	}

	public void setUserDefaultStatusUser(AppUserEntity userDefaultStatusUser) {
		this.userDefaultStatusUser = userDefaultStatusUser;
	}

	public String getUserDefaultStatusStatus() {
		return this.userDefaultStatusStatus;
	}

	public void setUserDefaultStatusStatus(String userDefaultStatusStatus) {
		this.userDefaultStatusStatus = userDefaultStatusStatus;
	}
}
