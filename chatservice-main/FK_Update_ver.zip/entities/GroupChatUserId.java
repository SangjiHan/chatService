package com.app.chatservice.entities;

import java.io.Serializable;
import java.util.Objects;

// import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Embeddable
public class GroupChatUserId implements Serializable {

	@ManyToOne
    @JoinColumn(name = "APPUSER_ID")
    private AppUserEntity groupChatUser;

	@ManyToOne
    @JoinColumn(name = "GROUP_CHAT_ID")
    private GroupChatEntity groupChatUserGroup;

    public GroupChatUserId() {}
    public GroupChatUserId(AppUserEntity groupChatUser, GroupChatEntity groupChatUserGroup) {
        this.groupChatUser = groupChatUser;
        this.groupChatUserGroup = groupChatUserGroup;
    }

    public AppUserEntity getGroupChatUser() {
        return groupChatUser;
    }
    public void setGroupChatUser(AppUserEntity groupChatUser) {
        this.groupChatUser = groupChatUser;
    }
    public GroupChatEntity getGroupChatUserGroup() {
        return groupChatUserGroup;
    }
    public void setGroupChatUserGroup(GroupChatEntity groupChatUserGroup) {
        this.groupChatUserGroup = groupChatUserGroup;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GroupChatUserId groupChatUserId = (GroupChatUserId) o;
        return Objects.equals(groupChatUser, groupChatUserId.groupChatUser) && 
                Objects.equals(groupChatUserGroup, groupChatUserId.groupChatUserGroup);
    }

    @Override
    public int hashCode() {
        return Objects.hash(groupChatUser, groupChatUserGroup);
    }
}
