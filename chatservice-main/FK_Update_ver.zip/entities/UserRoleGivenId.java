package com.app.chatservice.entities;

import java.io.Serializable;
import java.util.Objects;

// import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Embeddable
public class UserRoleGivenId implements Serializable {

	@ManyToOne
    @JoinColumn(name = "USER_ROLE_ID")
    private UserRoleEntity userRoleGivenRole;

	@ManyToOne
    @JoinColumn(name = "APPUSER_ID")
    private AppUserEntity userRoleGivenUser;

    public UserRoleGivenId() {};
    public UserRoleGivenId(UserRoleEntity userRoleGivenRole, AppUserEntity userRoleGivenUser) {
        this.userRoleGivenRole = userRoleGivenRole;
        this.userRoleGivenUser = userRoleGivenUser;
    }

    public UserRoleEntity getUserRoleGivenRole() {
        return userRoleGivenRole;
    }

    public void setUserRoleGivenRole(UserRoleEntity userRoleGivenRole) {
        this.userRoleGivenRole = userRoleGivenRole;
    }

    public AppUserEntity getUserRoleGivenUser() {
        return userRoleGivenUser;
    }
    
    public void setUserRoleGivenUser(AppUserEntity userRoleGivenUser) {
        this.userRoleGivenUser = userRoleGivenUser;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserRoleGivenId userRoleGivenId = (UserRoleGivenId) o;
        return Objects.equals(userRoleGivenRole, userRoleGivenId.userRoleGivenRole) && 
                Objects.equals(userRoleGivenUser, userRoleGivenId.userRoleGivenUser);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userRoleGivenRole, userRoleGivenUser);
    }
}
