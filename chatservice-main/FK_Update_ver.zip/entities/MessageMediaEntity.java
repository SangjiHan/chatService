package com.app.chatservice.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "MESSAGE_MEDIA")
public class MessageMediaEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "MESSAGE_MEDIA_ID")
    private String messageMediaId;

    @ManyToOne
    @JoinColumn(name = "MESSAGE_ID")
    private MessageEntity messageMediaMessage;

    @Column(name = "MESSAGE_MEDIA_FILE_NAME")
    private String messageMediaFileName;

    @Column(name = "MESSAGE_MEDIA_ORDER")
    private int messageMediaOrder;

    public String getMessageMediaId() {
        return messageMediaId;
    }
    public void setMessageMediaId(String messageMediaId) {
        this.messageMediaId = messageMediaId;
    }
    public MessageEntity getMessageMediaMessage() {
        return messageMediaMessage;
    }
    public void setMessageMediaMessage(MessageEntity messageMediaMessage) {
        this.messageMediaMessage = messageMediaMessage;
    }
    public String getMessageMediaFileName() {
        return messageMediaFileName;
    }
    public void setMessageMediaFileName(String messageMediaFileName) {
        this.messageMediaFileName = messageMediaFileName;
    }
    public int getMessageMediaOrder() {
        return messageMediaOrder;
    }
    public void setMessageMediaOrder(int messageMediaOrder) {
        this.messageMediaOrder = messageMediaOrder;
    }
}
