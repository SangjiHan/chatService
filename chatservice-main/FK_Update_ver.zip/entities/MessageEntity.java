package com.app.chatservice.entities;

import org.hibernate.annotations.Check;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

@Entity
@Table(name = "MESSAGE")
@Check(constraints = "((MESSAGE_CHANNEL IS NULL AND MESSAGE_GROUP_CHAT IS NOT NULL) OR (MESSAGE_CHANNEL IS NOT NULL AND MESSAGE_GROUP_CHAT IS NULL))")
public class MessageEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "MESSAGE_ID")
    private String messageId;

	@ManyToOne
    @JoinColumn(name = "CHANNEL_ID")
    private ChannelEntity messageChannel;

	@ManyToOne
    @JoinColumn(name = "GROUP_CHAT_ID")
    private GroupChatEntity messageGroupChat;

	@ManyToOne
    @JoinColumn(name = "APPUSER_ID")
    private AppUserEntity messageUser;

    @Column(name = "MESSAGE_REG_DATE")
    private Date messageRegDate;
    
    @Column(name = "MESSAGE_CONTENT")
    private String messageContent;

    @Column(name = "MESSAGE_EDITED")
    private int messageEdited = 0;

	@ManyToOne
    @JoinColumn(name = "REPLY_TO_MESSAGE_ID", nullable = true)
    private MessageEntity messageReplyTo;

    @Column(name = "MESSAGE_PING")
    private int messagePing = 0;

    @PrePersist
    public void onCreate() {
        this.messageRegDate = new Date();
    }

    public String getMessageId() {
        return messageId;
    }
    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }
    public ChannelEntity getMessageChannel() {
        return messageChannel;
    }
    public void setMessageChannel(ChannelEntity messageChannel) {
        this.messageChannel = messageChannel;
    }
    public GroupChatEntity getMessageGroupChat() {
        return messageGroupChat;
    }
    public void setMessageGroupChat(GroupChatEntity messageGroupChat) {
        this.messageGroupChat = messageGroupChat;
    }
    public AppUserEntity getMessageUser() {
        return messageUser;
    }
    public void setMessageUser(AppUserEntity messageUser) {
        this.messageUser = messageUser;
    }
    public Date getMessageRegDate() {
        return messageRegDate;
    }
    public void setMessageRegDate(Date messageRegDate) {
        this.messageRegDate = messageRegDate;
    }
    public String getMessageContent() {
        return messageContent;
    }
    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }
    public int getMessageEdited() {
        return messageEdited;
    }
    public void setMessageEdited(int messageEdited) {
        this.messageEdited = messageEdited;
    }
    public MessageEntity getMessageReplyTo() {
        return messageReplyTo;
    }
    public void setMessageReplyTo(MessageEntity messageReplyTo) {
        this.messageReplyTo = messageReplyTo;
    }
    public int getMessagePing() {
        return messagePing;
    }
    public void setMessagePing(int messagePing) {
        this.messagePing = messagePing;
    }
}
