package com.app.chatservice.entities;

import java.io.Serializable;
import java.util.Objects;

// import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Embeddable
public class UserDefaultStatusId implements Serializable {
    
	@ManyToOne
    @JoinColumn(name = "APPUSER_ID")
    private AppUserEntity appUser;

    public UserDefaultStatusId() {}
    public UserDefaultStatusId(AppUserEntity appUser) {
        this.appUser = appUser;
    }

    public AppUserEntity getAppUser() {
        return this.appUser;
    }

    public void setAppUser(AppUserEntity appUser) {
        this.appUser = appUser;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserDefaultStatusId userDefaultStatusId = (UserDefaultStatusId) o;
        return Objects.equals(appUser, userDefaultStatusId.appUser);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appUser);
    }
}
