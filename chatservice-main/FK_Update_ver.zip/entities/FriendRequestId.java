package com.app.chatservice.entities;

import java.io.Serializable;
import java.util.Objects;

// import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Embeddable
public class FriendRequestId implements Serializable {

	@ManyToOne
    @JoinColumn(name = "APPUSER_ID", insertable = false, updatable = false)
    private AppUserEntity friendRequestSender;

	@ManyToOne
    @JoinColumn(name = "APPUSER_ID", insertable = false, updatable = false)
    private AppUserEntity friendRequestReceiver;

    public FriendRequestId() {}
    public FriendRequestId(AppUserEntity friendRequestSender, AppUserEntity friendRequestReceiver) {
        this.friendRequestSender = friendRequestSender;
        this.friendRequestReceiver = friendRequestReceiver;
    }

    public AppUserEntity getFriendRequestSender() {
        return friendRequestSender;
    } 
    public void setFriendRequestSender(AppUserEntity friendRequestSender) {
        this.friendRequestSender = friendRequestSender;
    }
    public AppUserEntity getFriendRequestReceiver() {
        return friendRequestReceiver;
    } 
    public void setFriendRequestReceiver(AppUserEntity friendRequestReceiver) {
        this.friendRequestReceiver = friendRequestReceiver;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FriendRequestId friendRequestId = (FriendRequestId) o;
        return Objects.equals(friendRequestSender, friendRequestId.friendRequestSender) && 
                Objects.equals(friendRequestReceiver, friendRequestId.friendRequestReceiver);
    }

    @Override
    public int hashCode() {
        return Objects.hash(friendRequestSender, friendRequestReceiver);
    }
}
