package com.app.chatservice.entities;

import java.io.Serializable;
import java.util.Objects;

// import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Embeddable
public class ServerMemberId implements Serializable {

    @ManyToOne
    @JoinColumn(name = "APPUSER_ID")
    private AppUserEntity serverMemberUser;

    @ManyToOne
    @JoinColumn(name = "SERVER_ID")
    private ServerEntity serverMemberServer;    

    // 생성자
    public ServerMemberId() {};
    public ServerMemberId(AppUserEntity serverMemberUser, ServerEntity serverMemberServer) {
        this.serverMemberUser = serverMemberUser;
        this.serverMemberServer = serverMemberServer;
    }

    public AppUserEntity getServerMemberUser() {
        return serverMemberUser;
    }
    public void setServerMemberUser(AppUserEntity serverMemberUser) {
        this.serverMemberUser = serverMemberUser;
    }
    public ServerEntity getServerMemberServer() {
        return serverMemberServer;
    }
    public void setServerMemberServer(ServerEntity serverMemberServer) {
        this.serverMemberServer = serverMemberServer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ServerMemberId serverMemberId = (ServerMemberId) o;
        return Objects.equals(serverMemberUser, serverMemberId.serverMemberUser) && 
                Objects.equals(serverMemberServer, serverMemberId.serverMemberServer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(serverMemberUser, serverMemberServer);
    }
    @Override
    public String toString() {
        return "ServerMemberId [serverMemberUser=" + serverMemberUser + ", serverMemberServer=" + serverMemberServer
                + "]";
    }


}
