package com.app.chatservice.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "USER_ROLE", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"USER_ROLE_NAME", "USER_ROLE_SERVER"})
})
public class UserRoleEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
	@Column(name = "USER_ROLE_ID")
    private String userRoleId;

	@Column(name = "USER_ROLE_NAME")
    private String userRoleName;

	@ManyToOne
	@JoinColumn(name = "SERVER_ID")
    private ServerEntity userRoleServer;

    public String getUserRoleId() {
		return userRoleId;
	}
	public void setUserRoleId(String userRoleId) {
		this.userRoleId = userRoleId;
	}
	public String getUserRoleName() {
		return userRoleName;
	}
	public void setUserRoleName(String userRoleName) {
		this.userRoleName = userRoleName;
	}
	public ServerEntity getUserRoleServer() {
		return userRoleServer;
	}
	public void setUserRoleServer(ServerEntity userRoleServer) {
		this.userRoleServer = userRoleServer;
	}
}
